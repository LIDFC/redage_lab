// Добавляем в самый вверх
using NeptuneEvo.EternalDev.MarketPlace.Extensions;

// Ищем в функции buyBusinessCommand, sellBusinessCommand
if (!biz.Owner.Equals(player.Name))
// Добавляем перед
if (biz.IsOnMarketplace(player))
    return;

// Ищем в функции acceptBuyBusiness
if (player.Position.DistanceTo(target.Position) > 2)
// Добавляем перед
if (biz.IsOnMarketplace(player))
    return;