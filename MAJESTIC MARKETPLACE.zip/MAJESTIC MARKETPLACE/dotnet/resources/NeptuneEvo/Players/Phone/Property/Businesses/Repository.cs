// Добавляем в самый вверх
using NeptuneEvo.EternalDev.MarketPlace.Extensions;

// Ищем в функции OnSellConfirm
var biz = BusinessManager.BizList[bizId];
// Добавляем после
if (biz.IsOnMarketplace(player))
    return;


// Ищем
Houses.Rieltagency.Repository.OnPayDay(new List<Houses.House>(), new List<Business>()
{
    biz
});
// Заменяем на
EternalDev.MarketPlace.Auction.AuctionManager.SetPropertyToAuction(biz);