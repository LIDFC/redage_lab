//  Добавляем в самый вверх
using NeptuneEvo.EternalDev.MarketPlace.Extensions;
using Vehicles = Database.Vehicles;

// Ищем в функции callback_sellcar
if (vehicleData == null) return;
// Меняем на
if (vehicleData == null || vehicleData.IsOnMarketplace(player)) return;