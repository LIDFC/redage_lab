// Ищем 
// public static void Remove(ExtPlayer player, string locationName, string Location, ItemId ItemId, int count = 1)
// Заменяем на
public static void Remove(ExtPlayer player, string locationName, string Location, ItemId ItemId, int count = 1, string data = null)

// В этой же функции ищем
// if (item.Value.ItemId == ItemId)
// Заменяем на
if (item.Value.ItemId == ItemId && (data == null ? true : item.Value.Data == data))


// Ищем
// public static int getCountToLacationItem(string locationName, string Location, ItemId ItemId
// Заменяем на
public static int getCountToLacationItem(string locationName, string Location, ItemId ItemId, string data = null)

// В этой функции ищем
// else if (itemData.ItemId != ItemId) continue;
// Заменяем на
else if (itemData.ItemId != ItemId || (data == null ? false : itemData.Data != data)) 
    continue;