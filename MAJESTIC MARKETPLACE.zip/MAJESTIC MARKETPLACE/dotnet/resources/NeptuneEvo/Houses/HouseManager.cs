// Добавляем в самый вверх
using NeptuneEvo.EternalDev.MarketPlace.Extensions;

// Ищем в функции acceptHouseSellToGov
house.RemoveAllPlayers();
house.ClearOwner();

// Добавляем перед
if (house.IsOnMarketplace(player))
    return;

// Ищем
Rieltagency.Repository.OnPayDay(new List<House>()
{
    house
}, new List<Business>());
// Заменяем на
EternalDev.MarketPlace.Auction.AuctionManager.SetPropertyToAuction(house);

// Ищем функцию VehicleAction и там ищем case "sell"
sessionData.CarSellGov = number;
// Вставляем перед
if (vehicleData.IsOnMarketplace(player))
    return;

// Ищем в функции OfferHouseSell
if (GetHouse(target, true) != null)
// Добавляем перед
if (house.IsOnMarketplace(player))
    return;


// Ищем в функции acceptHouseSell
int tax = Convert.ToInt32(house.Price / 100 * 0.026);
// Добавляем перед
if (house.IsOnMarketplace(player))
    return;


// Ищем
// static List<int> MaxRoommates = new List<int>() {
// Если в начале строки стоит private, то заменяем на public
// Если в начале строки уже стоит public, то все хорошо!