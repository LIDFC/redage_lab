// Ищем   public enum ColShapeEnums
// Добавляем туда

MarketPlaceInterior,
MarketPlaceAuction,
MarketPlaceStorage