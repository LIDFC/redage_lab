// Добавляем в пустое место

public class BusinessStatsDTO
{
    [JsonProperty("income")]
    public int Income { get; set; }

    [JsonProperty("netProfit")]
    public int NetProfit { get; set; }

    [JsonProperty("averageCheck")]
    public int AverageCheck { get; set; }

    [JsonProperty("governmentPrice")]
    public int GovernmentPrice { get; set; }

    [JsonProperty("salesCount")]
    public int SalesCount { get; set; }

    [JsonProperty("profitability")]
    public int Profitability { get; set; }
}

public static async Task<Dictionary<string, BusinessStatsDTO>> GetBusinessStats(int bizId)
{
    if (!BusinessManager.BizList.TryGetValue(bizId, out var business))
        return null;

    await using var db = new ServerBD("MainDB");

    var historyList = await db.Businesshistory
        .Where(bh => bh.Bizid == bizId)
        .OrderByDescending(bh => bh.Autoid)
        .Select(bh => new
        {
            bh.Item,
            bh.Uuid,
            bh.Date,
            bh.Price
        })
        .ToListAsync();

    BusinessStatsDTO GetData(int days)
    {
        var historyPerTime = historyList.Where(x => x.Date >= DateTime.Now.Subtract(new TimeSpan(days, 0, 0, 0)));

        var count = historyPerTime.Count();
        return new BusinessStatsDTO()
        {
            Income = business.Pribil,
            NetProfit = Math.Max(business.Pribil - business.Zatratq, 0),
            AverageCheck = count == 0 ? 0 : (int)Math.Round((decimal)historyPerTime.Select(x => x.Price).Sum() / count),
            GovernmentPrice = business.SellPrice,
            SalesCount = historyPerTime.Count(),
            Profitability = business.Zatratq == 0 ? 0 : Math.Max((int)Math.Round((decimal)business.Pribil / business.Zatratq * 100), 0),
        };
    }

    var result = new Dictionary<string, BusinessStatsDTO>();

    result.Add("yesterday", GetData(1));
    result.Add("week", GetData(7));
    result.Add("month", GetData(30));
    result.Add("quarter", GetData(GetDaysPassedOfCurrentQuarter()));
    result.Add("year", GetData(365));

    return result;
}

public static int GetDaysPassedOfCurrentQuarter()
{
    DateTime today = DateTime.Today;
    DateTime startOfNextQuarter = GetStartOfNextQuarter(today);
    return (today - startOfNextQuarter).Days;
}

public static DateTime GetStartOfNextQuarter(DateTime date)
{
    int year = date.Year;
    int month = (date.Month - 1) / 3 * 3 + 4; 

    if (month > 12)
    {
        month = 1;
        year++;
    }

    return new DateTime(year, month, 1);
}