// Ищем
// Houses.Rieltagency.Repository.OnPayDay(houses, businesses);
// Удаляем

// В этой же функции (ВАЖНО!), чуть выше находим
// houses.Add(house);
// Заменяем на
EternalDev.MarketPlace.Auction.AuctionManager.SetPropertyToAuction(house);

// В этой же функции (ВАЖНО!), еще выше находим
// businesses.Add(biz);
// Заменяем на
EternalDev.MarketPlace.Auction.AuctionManager.SetPropertyToAuction(biz);