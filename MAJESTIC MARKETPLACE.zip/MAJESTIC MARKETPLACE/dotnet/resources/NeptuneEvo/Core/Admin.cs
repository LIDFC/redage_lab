// Ищем
await Players.Phone.Tinder.Repository.Saves(db);
// Добавляем после
EternalDev.MarketPlace.Manager.Save();